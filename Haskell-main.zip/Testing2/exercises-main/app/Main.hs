module Main (main) where

import qualified Lecture4

main :: IO ()
main = Lecture4.main
