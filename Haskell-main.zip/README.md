# Haskell
Latihan saya dalam mencoba latihan Bahasa haskell
